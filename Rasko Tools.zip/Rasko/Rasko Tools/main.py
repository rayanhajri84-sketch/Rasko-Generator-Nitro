import os,time,random,string
from rich.console import Console
from rich.panel import Panel

console=Console()
rng=random.SystemRandom()
chars=string.ascii_uppercase+string.digits

def code():
    return "".join(rng.choice(chars) for _ in range(16))

os.system("cls" if os.name=="nt" else "clear")
console.print(Panel.fit(
"[bold cyan]BY RASKO[/bold cyan]\n"
"[white]01 - Generate Random Codes[/white]\n\n"
"[bright_black]Press CTRL+C to stop[/bright_black]",
border_style="cyan"))

choice=input("\nSelect > ").strip()

if choice=="01":
    console.print("\n[green]Generating...[/green]\n")
    try:
        while True:
            console.print(code())
            time.sleep(0.2)   # ~5 codes/sec
    except KeyboardInterrupt:
        console.print("\n[red]Stopped.[/red]")
else:
    console.print("[red]Invalid option.[/red]")
    input("Press ENTER...")
